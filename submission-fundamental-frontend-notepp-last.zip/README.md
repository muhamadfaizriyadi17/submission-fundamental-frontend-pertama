# submission-fundamental-frontend-pertama
Submission Dicoding Belajar Fundamental Frontend Membuat Web Aplikasi Note-App Menggunakan Javascript dan Custom Element
